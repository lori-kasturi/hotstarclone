from django.contrib import admin
from .models import BannerCards, Cards
# Register your models here.

admin.site.register(BannerCards)
admin.site.register(Cards)